const { menu } = require('../data/menu');
const { reserva } = require('../data/reserva');

function calcularTotal(reserva) {
    if (!menu || !reserva || !reserva.itemsReservados) {
        throw new Error('Datos de reserva o menú no válidos');
    }
    const total = reserva.itemsReservados.reduce((acc, item) => {
        const plato = menu.find(p => p.id === item.platoId);
        return acc + (plato.precio * item.cantidad);
    }, 0);
    return total;
}

function verificarExpiracionReserva(reserva) {
    if (reserva.estado !== 'pendiente') {
        return false;
    }

    if (new Date() >= new Date(reserva.fechaExpiracion)) {

        // Devolver al inventario todo lo que estaba apartado
        for (const item of reserva.itemsReservados) {
            const plato = menu.find(p => p.id === item.platoId);

            if (plato) {
                plato.stock += item.cantidad;
            }
        }

        reserva.itemsReservados = [];
        reserva.total = 0;
        reserva.estado = 'expirada';

        return false;
    }

    return true;
}

function buscarReserva(reservaId) {
    if (reserva.id !== Number(reservaId)) {
        throw new Error('Reserva no encontrada');
    }
    return reserva;
}

function getReserva(reservaId) {
    const reservaEncontrada = buscarReserva(reservaId);

    verificarExpiracionReserva(reservaEncontrada);

    return reservaEncontrada;
}

function agregarReserva(reservaId, platoId, cantidad) {
    const reserva = buscarReserva(reservaId);
    platoId = Number(platoId);
    cantidad = Number(cantidad);
    if (!Number.isInteger(cantidad) || cantidad <= 0) {
        throw new Error('La cantidad debe ser un entero positivo');
    }
    if (reserva.estado !== 'pendiente') {
        throw new Error('La reserva no está pendiente');
    }
    if (!verificarExpiracionReserva(reserva)) {
        throw new Error('La reserva ha expirado');
    }
    const plato = menu.find(p => p.id === platoId);
    if (!plato) {
        throw new Error('Plato no encontrado en el menú');
    }
    const itemExistente = reserva.itemsReservados.find(
        item => item.platoId === platoId
    );
    const cantidadActual = itemExistente ? itemExistente.cantidad : 0;
    const cantidadTotal = cantidadActual + cantidad;
    if (cantidad > plato.stock) {
        throw new Error('Stock insuficiente');
    }
    const nuevoTotal = calcularTotal(reserva) + plato.precio * cantidad;
    if (nuevoTotal > reserva.saldo) {
        throw new Error('Saldo insuficiente');
    }
    if (itemExistente) {
        itemExistente.cantidad = cantidadTotal;
    } else {
        reserva.itemsReservados.push({ platoId, cantidad });
    }
    plato.stock -= cantidad;
    reserva.total = nuevoTotal;

    return reserva;
}

function actualizarPorciones(reservaId, platoId, nuevaCantidad) {
    const reserva = buscarReserva(reservaId);

    verificarExpiracionReserva(reserva);

    if (reserva.estado !== 'pendiente') {
        throw new Error('La reserva ya no está disponible');
    }

    if (!Number.isInteger(nuevaCantidad) || nuevaCantidad <= 0) {
        throw new Error('La cantidad debe ser mayor a 0');
    }

    const item = reserva.itemsReservados.find(
        (item) => item.platoId === platoId
    );

    if (!item) {
        throw new Error('Plato no encontrado en la reserva');
    }

    const plato = menu.find((plato) => plato.id === platoId);

    if (!plato) {
        throw new Error('Plato no encontrado');
    }

    // Diferencia entre la cantidad nueva y la que ya tenía
    const diferencia = nuevaCantidad - item.cantidad;

    // Si aumenta la cantidad, necesitamos más stock
    if (diferencia > 0 && diferencia > plato.stock) {
        throw new Error('Stock insuficiente');
    }

    const nuevoTotal =
        reserva.total + diferencia * plato.precio;

    if (nuevoTotal > reserva.saldo) {
        throw new Error('Saldo insuficiente para esta cantidad');
    }

    // Si diferencia es positiva, resta stock.
    // Si es negativa, automáticamente devuelve stock.
    plato.stock -= diferencia;

    item.cantidad = nuevaCantidad;
    reserva.total = nuevoTotal;

    return reserva;
}

function eliminarPlato(reservaId, platoId) {
    const reserva = buscarReserva(reservaId);

    verificarExpiracionReserva(reserva);

    if (reserva.estado !== 'pendiente') {
        throw new Error('La reserva ya no está disponible');
    }

    const indice = reserva.itemsReservados.findIndex(
        (item) => item.platoId === platoId
    );

    if (indice === -1) {
        throw new Error('Plato no encontrado en la reserva');
    }

    const item = reserva.itemsReservados[indice];

    const plato = menu.find(
        (plato) => plato.id === platoId
    );

    if (!plato) {
        throw new Error('Plato no encontrado');
    }

    // Devolver al inventario las unidades que estaban reservadas
    plato.stock += item.cantidad;

    reserva.itemsReservados.splice(indice, 1);

    reserva.total = calcularTotal(reserva);

    return reserva;
}

function confirmarReserva(reservaId) {
    const reserva = buscarReserva(reservaId);

    if (reserva.estado !== 'pendiente') {
        throw new Error('La reserva no está pendiente');
    }

    if (!verificarExpiracionReserva(reserva)) {
        throw new Error('La reserva ha expirado');
    }

    if (reserva.itemsReservados.length === 0) {
        throw new Error('No se puede confirmar una reserva sin platos');
    }

    // Verificamos que los platos todavía existan en el menú
    for (const item of reserva.itemsReservados) {
        const plato = menu.find(p => p.id === item.platoId);

        if (!plato) {
            throw new Error('Uno de los platos no existe en el menú');
        }
    }

    const total = calcularTotal(reserva);

    if (total > reserva.saldo) {
        throw new Error('Saldo insuficiente');
    }

    // El stock NO se descuenta aquí porque ya fue apartado
    // al agregar/modificar los platos de la reserva.

    reserva.total = total;
    reserva.saldo -= total;
    reserva.estado = 'confirmada';

    return reserva;
}

function reiniciarReserva(reservaId) {
    const reserva = buscarReserva(reservaId);

    if (reserva.estado === 'pendiente') {
        throw new Error('La reserva actual todavía está pendiente');
    }

    reserva.itemsReservados = [];
    reserva.total = 0;
    reserva.estado = 'pendiente';
    reserva.fechaExpiracion = new Date(Date.now() + 10 * 60 * 1000);

    return reserva;
}

module.exports = {
    getReserva,
    agregarReserva, 
    actualizarPorciones, 
    eliminarPlato,
    confirmarReserva,
    reiniciarReserva
};
